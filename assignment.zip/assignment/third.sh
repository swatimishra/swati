#!/bin/sh
# This is print details of add and multiply
add=`expr $1 + $2`
sub=`expr $1 - $2`
mul=`expr $1 \* $2`
echo Addtion of $1 and $2 is $add
echo Subtraction of $2 from $1 is $sub
echo Multiplication of $1 and $2 is $mul

