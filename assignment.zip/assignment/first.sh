#!/bin/sh
# This is print details name,id,program
echo Enter your name
read name
echo Enter your program name
read prog
echo Enter your id number
read id
clear
echo Details you entered
echo Name:$name
echo Program Name:$prog
echo id Number:$id
