#!/bin/bash
# fact1
# Finding factorial of a given number

echo "Enter a number"
read num
fact=1
n=$num
while [ $num -ge 1 ]
do

  fact=`echo $fact \* $num|bc`
